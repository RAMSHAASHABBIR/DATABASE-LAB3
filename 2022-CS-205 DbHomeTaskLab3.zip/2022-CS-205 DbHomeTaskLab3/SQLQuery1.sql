USE [northwind]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*Q1*/
SELECT* FROM Orders WHERE RequiredDate < ShippedDate
/*Q2*/
SELECT DISTINCT [Country] FROM Employees
/*Q3*/
SELECT* FROM Employees WHERE  ReportsTo IS NULL
/*Q4*/
SELECT [ProductName] FROM Products WHERE Discontinued = 0
/*Q5*/
SELECT [OrderID],[ProductID] FROM [Order Details] WHERE Discount = 0
/*Q6*/
SELECT [CustomerID] FROM Customers WHERE Region IS NULL
/*Q7*/
SELECT [CustomerID],[ContactName] FROM Customers WHERE Country IN('UK','USA')
/*Q8*/
SELECT [CompanyName] FROM Suppliers WHERE HomePage IS NOT NULL
/*Q9*/
SELECT [ShipCountry] FROM Orders WHERE ShippedDate >='1997-01-01 00:00:00.000' AND ShippedDate < '1998-01-01 00:00:00.000'
/*Q10*/
SELECT [CustomerID] FROM Orders WHERE ShipRegion IS NULL
/*Q11*/
SELECT [SupplierID],[CompanyName],[City] FROM Suppliers
/*Q12*/
SELECT  [EmployeeID],[LastName],[FirstName] FROM Employees WHERE City = 'London'
/*Q13*/
SELECT [ProductName] FROM Products WHERE Discontinued = 1
/*Q14*/
SELECT [OrderID],[ProductID] FROM [Order Details] WHERE Discount <= 0.1
/*Q15*/
SELECT [EmployeeID],[LastName],[FirstName],[HomePhone],[Extension]FROM Employees WHERE Region IS NULL